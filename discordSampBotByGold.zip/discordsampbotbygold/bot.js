const Discord = require('discord.js');
const client = new Discord.Client();
;

client.on('ready', () => {
  console.log(`BOT: ${client.user.username} adı ile giriş yaptı!`);
});

client.on('message', message => {
    if (message.content === '!yetkilialımları') {
    	message.reply('Yetkili Alımları Forumumuzdan Yada Discord Sunucumuzdan Duyurulacaktır.');
  	}
});

client.on('message', message => {
    if (message.content === '!forum') {
    	message.reply('www.siteniziyazın.com burayı bot.jsden düzenleyebilirsin.');
  	}
});

client.on('message', message => {
    if (message.content === '!sampbot') {
    	message.reply('Samp Bot Samp Serverlerde İşe Yaraması İçin Yapılmıştır.');
  	}
});

client.on('message', message => {
    if (message.content === '!vip') {
    	message.reply('Vip Satın Almak İçin Sunucu Sahibiyle Konuşun😎');
  	}
});

client.on('message', message => {
    if (message.content === '!yapımcı') {
    	message.reply('Botun Kodlayacısı Ve Yapımcısı ByGold.');
  	}
});
      
client.on('message', message => {
    if (message.content === 'Selamun Aleykum') {
    	message.reply('Aleykum Selam Hoşgeldin🌷');
  	}
});

client.on('message', message => {
    if (message.content === 'sa') {
    	message.reply('Aleykum Selam Hoşgeldin🌷');
  	}
});

client.on('message', message => {
    if (message.content === '!yetkililer') {
    	message.reply('Sunucu Yetkilileri Daha Belli Değil Bu Komutu Bot.jsden Düzenleyin');
  	}
});

client.on('message', message => {
    if (message.content === '!destek') {
    	message.reply('Herhangi Bir Sorununuz Varsa Yetkililerle İletişime Geçin.');
  	}
});

client.on('message', message => {
    if (message.content === '!beniseviyormusun') {
        message.reply('evet🌷');
  	}
});
  
client.on('message', message => {
    if (message.content === '!komutlar') {
    	message.reply('!sunucuip,!yetkililer,!vip,!forum,!sampbot,!destek,!yetkilialımları,!yapımcı');
  	}
});

client.on('message', message => {
    if (message.content === '!sunucuip') {
    	message.reply('https://samp.server-listesi.com/banner/77/FFC200/FFFFFF/bg1_samp/808080/000000/000000/false Burayı bot.jsden düzenleyebilirsiniz');
  	}
});
 
// THIS  MUST  BE  THIS  WAY
client.login(process.env.BOT_TOKEN)
